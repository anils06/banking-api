package com.minibanking.mini_banking_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniBankingApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniBankingApiApplication.class, args);
	}

}
