package com.minibanking.mini_banking_api.controllers;

import com.minibanking.mini_banking_api.models.Account;
import com.minibanking.mini_banking_api.models.User;
import com.minibanking.mini_banking_api.payload.AccountSearchRequest;
import com.minibanking.mini_banking_api.payload.MessageResponse;
import com.minibanking.mini_banking_api.repositories.AccountRepository;
import com.minibanking.mini_banking_api.repositories.UserRepository;
import com.minibanking.mini_banking_api.security.services.UserDetailsImpl;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    private final AccountRepository accountRepository;
    private final UserRepository userRepository;

    public AccountController(AccountRepository accountRepository, UserRepository userRepository) {
        this.accountRepository = accountRepository;
        this.userRepository = userRepository;
    }

    private UserDetailsImpl getAuthenticatedUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof UserDetailsImpl) {
            return (UserDetailsImpl) authentication.getPrincipal();
        }
        throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "User not authenticated");
    }

    // GET /api/accounts - List all accounts of the logged-in user
    @GetMapping
    public ResponseEntity<List<Account>> getAllAccountsForUser() {
        UserDetailsImpl userDetails = getAuthenticatedUser();
        List<Account> accounts = accountRepository.findByUserId(userDetails.getId());

        // --- LOG LINE ---
        System.out.println(">>> Bulunan hesap sayısı: " + accounts.size());
        // --- END LOG LINE ---

        return ResponseEntity.ok(accounts);
    }

    // 1. Create Account
    @PostMapping
    public ResponseEntity<?> createAccount(@Valid @RequestBody Account newAccountRequest) {
        UserDetailsImpl userDetails = getAuthenticatedUser();
        User currentUser = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        Account account = new Account();
        account.setName(newAccountRequest.getName());
        account.setNumber(newAccountRequest.getNumber());
        account.setBalance(newAccountRequest.getBalance() != null ? newAccountRequest.getBalance() : BigDecimal.ZERO);
        account.setUser(currentUser);

        Account savedAccount = accountRepository.save(account);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedAccount);
    }

    // 5. View Account Details
    @GetMapping("/{id}")
    public ResponseEntity<Account> getAccountDetails(@PathVariable UUID id) {
        UserDetailsImpl userDetails = getAuthenticatedUser();
        Account account = accountRepository.findByIdAndUserId(id, userDetails.getId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Account not found or access denied"));
        return ResponseEntity.ok(account);
    }

    // 4. Delete Account
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteAccount(@PathVariable UUID id) {
        UserDetailsImpl userDetails = getAuthenticatedUser();
        Account account = accountRepository.findByIdAndUserId(id, userDetails.getId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Account not found or access denied"));
        accountRepository.delete(account);
        return ResponseEntity.ok(new MessageResponse("Account deleted successfully!"));
    }

    // 3. Update Account
    @PutMapping("/{id}")
    public ResponseEntity<?> updateAccount(@PathVariable UUID id, @Valid @RequestBody Account updateRequest) {
        UserDetailsImpl userDetails = getAuthenticatedUser();
        Account existingAccount = accountRepository.findByIdAndUserId(id, userDetails.getId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Account not found or access denied"));
        existingAccount.setName(updateRequest.getName());
        Account updatedAccount = accountRepository.save(existingAccount);
        return ResponseEntity.ok(updatedAccount);
    }

    // 2. Search Accounts
    @PostMapping("/search")
    public ResponseEntity<List<Account>> searchAccounts(@RequestBody AccountSearchRequest searchRequest) {
        UserDetailsImpl userDetails = getAuthenticatedUser();
        List<Account> accounts;
        if (searchRequest.getName() != null) {
            accounts = accountRepository.findByUserIdAndNameContainingIgnoreCase(userDetails.getId(), searchRequest.getName());
        } else if (searchRequest.getNumber() != null) {
            accounts = accountRepository.findByUserIdAndNumberContainingIgnoreCase(userDetails.getId(), searchRequest.getNumber());
        } else {
            accounts = accountRepository.findByUserId(userDetails.getId());
        }
        return ResponseEntity.ok(accounts);
    }
}