package com.minibanking.mini_banking_api.controllers;

import com.minibanking.mini_banking_api.models.Transaction;
import com.minibanking.mini_banking_api.payload.TransferRequest;
import com.minibanking.mini_banking_api.security.services.UserDetailsImpl;
import com.minibanking.mini_banking_api.services.TransactionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.UUID;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/transactions") // All endpoints in this class will start with /api/transactions
public class TransactionController {

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    // HELPER METHOD TO GET THE LOGGED-IN USER'S DETAILS
    private UserDetailsImpl getAuthenticatedUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof UserDetailsImpl) {
            return (UserDetailsImpl) authentication.getPrincipal();
        }
        throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "User not authenticated");
    }

    // 1. Initiate Money Transfer
    @PostMapping("/transfer")
    public ResponseEntity<Transaction> transferMoney(@Valid @RequestBody TransferRequest transferRequest) {
        UserDetailsImpl userDetails = getAuthenticatedUser();

        // Core business logic (balance check, @Transactional) is handled in the Service layer
        Transaction transaction = transactionService.transferMoney(
                transferRequest.getFromAccountId(),
                transferRequest.getToAccountId(),
                transferRequest.getAmount(),
                userDetails.getId() // Security: Also send the user's ID
        );

        return ResponseEntity.status(HttpStatus.CREATED).body(transaction);
    }

    // 2. View Transaction History
    @GetMapping("/account/{accountId}")
    public ResponseEntity<List<Transaction>> getTransactionHistory(@PathVariable UUID accountId) {
        UserDetailsImpl userDetails = getAuthenticatedUser();

        // Core business logic (checking if the account belongs to the user) is handled in the Service layer
        List<Transaction> history = transactionService.getTransactionHistory(
                accountId,
                userDetails.getId() // Security: Also send the user's ID
        );

        return ResponseEntity.ok(history);
    }
}