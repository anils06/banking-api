package com.minibanking.mini_banking_api.models;

public enum TransactionStatus {
    SUCCESS,
    FAILED
}