package com.minibanking.mini_banking_api.payload;

import lombok.Data;

@Data
public class AccountSearchRequest {
    // For search, 'name' OR 'number' may be provided; neither is mandatory
    private String name;
    private String number;
}