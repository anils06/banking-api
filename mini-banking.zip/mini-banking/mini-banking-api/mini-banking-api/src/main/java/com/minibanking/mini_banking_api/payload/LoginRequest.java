package com.minibanking.mini_banking_api.payload;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data // This line generates getUsername() and getPassword() methods
public class LoginRequest {
    @NotBlank
    private String username;

    @NotBlank
    private String password;
}