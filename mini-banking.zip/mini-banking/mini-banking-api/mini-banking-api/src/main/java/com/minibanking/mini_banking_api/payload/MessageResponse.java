package com.minibanking.mini_banking_api.payload;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor // This line generates a constructor with a (String message) parameter
public class MessageResponse {
    private String message;
}