package com.minibanking.mini_banking_api.repositories;

import com.minibanking.mini_banking_api.models.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface AccountRepository extends JpaRepository<Account, UUID> {

    // Search methods required in the assessment
    // Search by specific user (userId) AND account name (name)
    List<Account> findByUserIdAndNameContainingIgnoreCase(UUID userId, String name);

    // Search by specific user (userId) AND account number (number)
    List<Account> findByUserIdAndNumberContainingIgnoreCase(UUID userId, String number);

    // Retrieve all accounts by user ID only
    List<Account> findByUserId(UUID userId);

    // Check if an account belongs to a specific user (for security)
    Optional<Account> findByIdAndUserId(UUID id, UUID userId);
}