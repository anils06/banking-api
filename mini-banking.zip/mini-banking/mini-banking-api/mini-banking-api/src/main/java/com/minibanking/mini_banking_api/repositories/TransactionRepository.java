package com.minibanking.mini_banking_api.repositories;

import com.minibanking.mini_banking_api.models.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    // The assessment requires transaction history for an account.
    // In a transaction, the account can be the 'sender' (from) OR the 'recipient' (to).
    // This method retrieves both cases (fromId OR toId).
    List<Transaction> findByFromIdOrToIdOrderByTransactionDateDesc(UUID fromId, UUID toId);

}