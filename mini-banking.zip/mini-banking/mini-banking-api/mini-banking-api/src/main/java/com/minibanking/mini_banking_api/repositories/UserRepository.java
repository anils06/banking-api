package com.minibanking.mini_banking_api.repositories; //

import com.minibanking.mini_banking_api.models.User; //
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;

public interface UserRepository extends JpaRepository<User, UUID> {

    // Spring Data JPA infers what to do from method names.
    // This method searches for a user by 'username'. Required for security.
    Optional<User> findByUsername(String username);

    // This method checks if 'username' exists in the database.
    Boolean existsByUsername(String username);

    // This method checks if 'email' exists in the database.
    Boolean existsByEmail(String email);
}