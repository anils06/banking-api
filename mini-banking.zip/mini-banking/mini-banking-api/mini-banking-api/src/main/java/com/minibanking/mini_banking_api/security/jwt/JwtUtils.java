package com.minibanking.mini_banking_api.security.jwt;

import com.minibanking.mini_banking_api.security.services.UserDetailsImpl;
import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;

@Component // Indicates that this class is a Spring component
public class JwtUtils {
    private static final Logger logger = LoggerFactory.getLogger(JwtUtils.class);

    // Reads the secret key from application.properties
    @Value("${mini.banking.app.jwtSecret}")
    private String jwtSecret;

    // Reads the expiration time from application.properties
    @Value("${mini.banking.app.jwtExpirationMs}")
    private int jwtExpirationMs;

    // Method that generates a token using the authenticated user's information
    public String generateJwtToken(Authentication authentication) {

        UserDetailsImpl userPrincipal = (UserDetailsImpl) authentication.getPrincipal();

        return Jwts.builder()
                .subject((userPrincipal.getUsername())) // Token "subject" (username)
                .issuedAt(new Date()) // Creation time
                .expiration(new Date((new Date()).getTime() + jwtExpirationMs)) // Expiration time
                .signWith(key(), Jwts.SIG.HS256) // Signing key and algorithm
                .compact();
    }

    // Converts the String key from application.properties to a Key object that Jwts can understand
    private SecretKey key() {
        return Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
    }

    // Method to extract 'username' from the incoming token
    public String getUserNameFromJwtToken(String token) {
        return Jwts.parser()
                .verifyWith(key())
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .getSubject();
    }

    // Method to check if the incoming token is valid (signature correct, not expired, etc.)
    public boolean validateJwtToken(String authToken) {
        try {
            Jwts.parser().verifyWith(key()).build().parse(authToken);
            return true;
        } catch (MalformedJwtException e) {
            logger.error("Invalid JWT token: {}", e.getMessage());
        } catch (ExpiredJwtException e) {
            logger.error("JWT token is expired: {}", e.getMessage());
        } catch (UnsupportedJwtException e) {
            logger.error("JWT token is unsupported: {}", e.getMessage());
        } catch (IllegalArgumentException e) {
            logger.error("JWT claims string is empty: {}", e.getMessage());
        }

        return false;
    }
}