package com.minibanking.mini_banking_api.security.services;

import com.minibanking.mini_banking_api.models.User;
import com.minibanking.mini_banking_api.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service // Indicates that this class is a Spring Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired // Automatically injects UserRepository into Spring
    UserRepository userRepository;

    // Spring Security calls the 'loadUserByUsername' method
    @Override
    @Transactional
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Using our UserRepository, search for the user by 'username'
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User Not Found with username: " + username));

        // Convert the found 'User' object into a format understandable by Spring Security
        // using 'UserDetailsImpl.build' method and return it.
        return UserDetailsImpl.build(user);
    }
}