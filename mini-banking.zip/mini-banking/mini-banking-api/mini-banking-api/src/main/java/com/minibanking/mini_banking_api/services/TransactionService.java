package com.minibanking.mini_banking_api.services;

import com.minibanking.mini_banking_api.models.Account;
import com.minibanking.mini_banking_api.models.Transaction;
import com.minibanking.mini_banking_api.models.TransactionStatus;
import com.minibanking.mini_banking_api.repositories.AccountRepository;
import com.minibanking.mini_banking_api.repositories.TransactionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service // Indicates that this class is a Spring Service
public class TransactionService {

    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;

    public TransactionService(AccountRepository accountRepository, TransactionRepository transactionRepository) {
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
    }

    // 1. Initiate Money Transfer
    // PDF: "Transfers can occur simultaneously" [cite: 58]
    // Therefore, we must use '@Transactional'.
    // This annotation ensures that ALL database operations inside the method are committed (saved) only if they all succeed.
    // If even one operation fails (e.g., insufficient funds), all operations are rolled back (undone).
    // This prevents situations where the money “gets lost in transit”.
    @Transactional
    public Transaction transferMoney(UUID fromAccountId, UUID toAccountId, BigDecimal amount, UUID userId) {

        // 1. Find sender and receiver accounts.
        Account fromAccount = accountRepository.findByIdAndUserId(fromAccountId, userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "From-Account not found or access denied"));

        Account toAccount = accountRepository.findById(toAccountId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "To-Account not found"));

        // 2. Prevent sending money to the same account
        if (fromAccountId.equals(toAccountId)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cannot transfer money to the same account");
        }

        // 3. Check balance.
        if (fromAccount.getBalance().compareTo(amount) < 0) {
            // If the balance is insufficient, throw an ERROR.
            // @Transactional will catch this and roll back the operation.
            // (We haven’t made any changes yet, but if we had, they would be undone.)
            // First, create a 'FAILED' transaction log:
            logTransaction(fromAccount, toAccount, amount, TransactionStatus.FAILED);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Insufficient funds");
        }

        // 4. Update balances (DEDUCT first, then ADD)
        fromAccount.setBalance(fromAccount.getBalance().subtract(amount));
        toAccount.setBalance(toAccount.getBalance().add(amount));

        // 5. Save accounts to the database
        accountRepository.save(fromAccount);
        accountRepository.save(toAccount);

        // 6. Create and return a 'SUCCESS' transaction log.
        return logTransaction(fromAccount, toAccount, amount, TransactionStatus.SUCCESS);
    }

    // Helper method for logging transaction history
    private Transaction logTransaction(Account from, Account to, BigDecimal amount, TransactionStatus status) {
        Transaction transaction = new Transaction();
        transaction.setFrom(from);
        transaction.setTo(to);
        transaction.setAmount(amount);
        transaction.setStatus(status);
        transaction.setTransactionDate(LocalDateTime.now());
        return transactionRepository.save(transaction);
    }

    // 2. View Transaction History
    public List<Transaction> getTransactionHistory(UUID accountId, UUID userId) {

        // 1. Verify that this account actually belongs to the user
        accountRepository.findByIdAndUserId(accountId, userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Account not found or access denied"));

        // 2. If the account belongs to the user, fetch the transaction history.
        // (Include transactions where the account was both the sender and receiver)
        return transactionRepository.findByFromIdOrToIdOrderByTransactionDateDesc(accountId, accountId);
    }
}