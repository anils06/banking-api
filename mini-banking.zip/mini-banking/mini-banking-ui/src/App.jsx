import React, { useState, useEffect } from 'react';
import './App.css';
import { Routes, Route, Link, useNavigate, Navigate } from 'react-router-dom';
import Login from './components/Login.jsx';
import Register from './components/Register.jsx';
import Dashboard from './components/Dashboard.jsx';
import Transfer from './components/Transfer.jsx';
import History from './components/History.jsx';
import { Container, Nav, Navbar, NavDropdown } from 'react-bootstrap';
import AuthService from './services/AuthService';

function App() {
    const [currentUser, setCurrentUser] = useState(undefined);
    const navigate = useNavigate();

    useEffect(() => {
        const user = AuthService.getCurrentUser();
        setCurrentUser(user ? user : null);
    }, []);

    const logOut = () => {
        AuthService.logout();
        setCurrentUser(null);
        navigate("/login");
    };

    if (currentUser === undefined) {
        return null; // Or a loading spinner
    }

    return (
        <>
            {/* Navbar (Unchanged) */}
            <Navbar bg="dark" variant="dark" expand="lg">
                <Container>
                    <Navbar.Brand as={Link} to="/">Mini Banka</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto">
                            {currentUser && (
                                <>
                                    <Nav.Link as={Link} to="/">Dashboard</Nav.Link>
                                    <Nav.Link as={Link} to="/transfer">Transfer</Nav.Link>
                                </>
                            )}
                        </Nav>
                        <Nav>
                            {currentUser ? (
                                <NavDropdown title={currentUser.username} id="basic-nav-dropdown">
                                    <NavDropdown.Item onClick={logOut}>Çıkış Yap</NavDropdown.Item>
                                </NavDropdown>
                            ) : (
                                <>
                                    <Nav.Link as={Link} to="/login">Giriş Yap</Nav.Link>
                                    <Nav.Link as={Link} to="/register">Kayıt Ol</Nav.Link>
                                </>
                            )}
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

            {/* Page Content */}
            <Container className="mt-4">
                <Routes>
                    <Route path="/" element={ currentUser ? <Dashboard /> : <Navigate to="/login" replace /> } />
                    <Route path="/transfer" element={ currentUser ? <Transfer /> : <Navigate to="/login" replace /> } />
                    {/* History Page - Dynamic and Protected Route */}
                    <Route
                        path="/history/:accountId" // NEW DYNAMIC ROUTE
                        element={ currentUser ? <History /> : <Navigate to="/login" replace /> }
                    />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                </Routes>
            </Container>
        </>
    );
}

export default App;