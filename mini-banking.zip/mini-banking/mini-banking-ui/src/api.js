import axios from 'axios';
import AuthService from './services/AuthService';

// The base URL of our backend API
const API_BASE_URL = "http://localhost:8080/api";

// Create a new Axios 'instance'
const apiClient = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Request Interceptor
// This function runs IMMEDIATELY BEFORE any request is sent via Axios
apiClient.interceptors.request.use(
    (config) => {
        // Try to get the current user (and token) from AuthService
        const user = AuthService.getCurrentUser();

        // If the user AND token exist:
        if (user && user.token) {
            // Add the token to the 'Authorization' header in the format "Bearer <token>"
            config.headers['Authorization'] = 'Bearer ' + user.token;
        }
        // Continue the request with the modified config
        return config;
    },
    (error) => {
        // If an error occurs before the request is sent
        return Promise.reject(error);
    }
);

// (We can add a Response Interceptor later — e.g., to automatically log out on a 401 error)

// Export this 'apiClient' object.
// From now on, we’ll use this instead of plain 'axios' for API requests.
export default apiClient;