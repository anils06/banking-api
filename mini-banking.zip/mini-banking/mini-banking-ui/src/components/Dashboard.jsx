import React, { useState, useEffect } from 'react';
import { Button, Card, Col, Row, Spinner, Alert, Form, InputGroup } from 'react-bootstrap';
import AccountService from '../services/AccountService.js';
import { Link } from 'react-router-dom'; // Import the Link component

const Dashboard = () => {
    const [accounts, setAccounts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [newAccountName, setNewAccountName] = useState('');
    const [newAccountNumber, setNewAccountNumber] = useState('');
    const [newAccountBalance, setNewAccountBalance] = useState('0.00');
    const [creatingAccount, setCreatingAccount] = useState(false);
    const [createError, setCreateError] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [searchType, setSearchType] = useState('name');
    const [searching, setSearching] = useState(false);
    const [deletingAccountId, setDeletingAccountId] = useState(null);
    const [deleteError, setDeleteError] = useState('');
    const [updatingAccountId, setUpdatingAccountId] = useState(null);
    const [updateError, setUpdateError] = useState('');

    const fetchAccounts = (searchCriteria = null) => {
        setLoading(true); setError(''); setDeleteError(''); setUpdateError('');
        let apiCall = searchCriteria ? AccountService.searchAccounts(searchCriteria) : AccountService.getAccounts();
        setSearching(!!searchCriteria);
        apiCall.then(response => { setAccounts(response.data); setLoading(false); setSearching(false); })
            .catch(error => {
                const errorMsg = (error.response?.data?.message) || error.message || error.toString();
                if (error.response && error.response.status === 401) { setError("Oturum süreniz dolmuş olabilir. Lütfen tekrar giriş yapın."); }
                else { setError("Hesaplar yüklenemedi/bulunamadı: " + errorMsg); }
                setLoading(false); setSearching(false); setAccounts([]);
            });
    };

    useEffect(() => { fetchAccounts(); }, []);

    const handleCreateAccount = (e) => {
        e.preventDefault(); setCreateError(''); setCreatingAccount(true);
        const accountData = { name: newAccountName, number: newAccountNumber, balance: newAccountBalance };
        AccountService.createAccount(accountData)
            .then(() => { setCreatingAccount(false); setNewAccountName(''); setNewAccountNumber(''); setNewAccountBalance('0.00'); fetchAccounts(); })
            .catch(error => { const errorMsg = (error.response?.data?.message) || error.message || error.toString(); setCreateError("Hesap oluşturulamadı: " + errorMsg); setCreatingAccount(false); });
    };

    const handleSearch = (e) => {
        e.preventDefault(); const searchCriteria = {};
        if (searchTerm.trim() === '') { fetchAccounts(); }
        else { searchCriteria[searchType] = searchTerm.trim(); fetchAccounts(searchCriteria); }
    };

    const handleDeleteAccount = (accountId) => {
        if (!window.confirm("Bu hesabı silmek istediğinizden emin misiniz?")) { return; }
        setDeletingAccountId(accountId); setDeleteError('');
        AccountService.deleteAccount(accountId)
            .then(() => { setDeletingAccountId(null); fetchAccounts(); })
            .catch(error => { const errorMsg = (error.response?.data?.message) || error.message || error.toString(); setDeleteError(`Hesap silinemedi (ID: ${accountId}): ${errorMsg}`); setDeletingAccountId(null); });
    };

    const handleUpdateAccount = (accountId, currentName) => {
        const newName = window.prompt("Yeni hesap adını girin:", currentName);
        if (newName && newName.trim() !== '' && newName.trim() !== currentName) {
            setUpdatingAccountId(accountId); setUpdateError('');
            const updateData = { name: newName.trim() };
            AccountService.updateAccount(accountId, updateData)
                .then(() => { setUpdatingAccountId(null); fetchAccounts(); })
                .catch(error => { const errorMsg = (error.response?.data?.message) || error.message || error.toString(); setUpdateError(`Hesap güncellenemedi (ID: ${accountId}): ${errorMsg}`); setUpdatingAccountId(null); });
        } else if (newName !== null) { setUpdateError("Yeni hesap adı girilmedi veya mevcut adla aynı."); setTimeout(() => setUpdateError(''), 3000); }
    };

    const formatCurrency = (amount) => {
        const numericAmount = typeof amount === 'number' ? amount : parseFloat(amount) || 0;
        return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(numericAmount);
    };

    return (
        <div>
            {/* Yeni Hesap Formu */}
            <Card className="mb-4">
                <Card.Header>Yeni Hesap Oluştur</Card.Header>
                <Card.Body>
                    {createError && <Alert variant="danger">{createError}</Alert>}
                    <Form onSubmit={handleCreateAccount}>
                        <Row>
                            <Col md={4}><Form.Group className="mb-3" controlId="newAccountName"><Form.Label>Hesap Adı</Form.Label><Form.Control type="text" placeholder="Örn: Vadesiz TL" value={newAccountName} onChange={(e) => setNewAccountName(e.target.value)} required /></Form.Group></Col>
                            <Col md={4}><Form.Group className="mb-3" controlId="newAccountNumber"><Form.Label>Hesap Numarası</Form.Label><Form.Control type="text" placeholder="Örn: TR12..." value={newAccountNumber} onChange={(e) => setNewAccountNumber(e.target.value)} required /></Form.Group></Col>
                            <Col md={4}><Form.Group className="mb-3" controlId="newAccountBalance"><Form.Label>Başlangıç Bakiyesi</Form.Label><InputGroup><InputGroup.Text>₺</InputGroup.Text><Form.Control type="number" step="0.01" placeholder="0.00" value={newAccountBalance} onChange={(e) => setNewAccountBalance(e.target.value)} required /></InputGroup></Form.Group></Col>
                        </Row>
                        <Button variant="success" type="submit" disabled={creatingAccount}>{creatingAccount && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true"/>} Hesap Oluştur</Button>
                    </Form>
                </Card.Body>
            </Card>

            {/* Mevcut Hesaplar */}
            <h2>Hesaplarım</h2>

            {/* Arama Formu */}
            <Form onSubmit={handleSearch} className="mb-3">
                <Row>
                    <Col md={6}><Form.Control type="text" placeholder="Arama terimi girin..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} /></Col>
                    <Col md={3}><Form.Select value={searchType} onChange={(e) => setSearchType(e.target.value)}><option value="name">Hesap Adına Göre</option><option value="number">Hesap Numarasına Göre</option></Form.Select></Col>
                    <Col md={3}>
                        <Button variant="info" type="submit" disabled={searching || loading}>{searching && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true"/>} Ara</Button>
                        {searchTerm && (<Button variant="secondary" className="ms-2" onClick={() => { setSearchTerm(''); fetchAccounts(); }} disabled={loading}>Temizle</Button>)}
                    </Col>
                </Row>
            </Form>

            {/* Hata Mesajları */}
            {error && <Alert variant="danger">{error}</Alert>}
            {deleteError && <Alert variant="danger">{deleteError}</Alert>}
            {updateError && <Alert variant="warning">{updateError}</Alert>}

            {/* Hesap Listesi */}
            {loading ? (
                <div className="text-center"><Spinner animation="border" /> Hesaplar yükleniyor...</div>
            ) : (
                <Row xs={1} md={2} lg={3} className="g-4 mt-1">
                    {accounts.length === 0 ? (
                        <Col>
                            <p>{searching ? 'Arama kriterlerine uygun hesap bulunamadı.' : 'Henüz bir hesabınız bulunmamaktadır.'}</p>
                        </Col>
                    ) : (
                        accounts.map((account) => (
                            <Col key={account.id}>
                                <Card>
                                    <Card.Body>
                                        <Card.Title>{account.name}</Card.Title>
                                        <Card.Subtitle className="mb-2 text-muted">{account.number}</Card.Subtitle>
                                        <Card.Text>
                                            <strong>Bakiye:</strong> {formatCurrency(account.balance)}
                                        </Card.Text>
                                        {/* DETAY BUTONU LİNKE DÖNÜŞTÜRÜLDÜ */}
                                        <Button
                                            as={Link} // Butonu Link olarak davranacak şekilde ayarla
                                            to={`/history/${account.id}`} // Hedef URL: /history/<hesap_id>
                                            variant="outline-info"
                                            size="sm"
                                            className="me-2"
                                        >
                                            Detay/Geçmiş
                                        </Button>
                                        {/* Güncelle ve Sil Butonları aynı kaldı */}
                                        <Button variant="outline-secondary" size="sm" className="me-2" onClick={() => handleUpdateAccount(account.id, account.name)} disabled={updatingAccountId === account.id || deletingAccountId === account.id}>
                                            {updatingAccountId === account.id ? ( <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true"/> ) : ( 'Güncelle' )}
                                        </Button>
                                        <Button variant="outline-danger" size="sm" onClick={() => handleDeleteAccount(account.id)} disabled={deletingAccountId === account.id || updatingAccountId === account.id}>
                                            {deletingAccountId === account.id ? ( <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true"/> ) : ( 'Sil' )}
                                        </Button>
                                    </Card.Body>
                                </Card>
                            </Col>
                        ))
                    )}
                </Row>
            )}
        </div>
    );
};

export default Dashboard;