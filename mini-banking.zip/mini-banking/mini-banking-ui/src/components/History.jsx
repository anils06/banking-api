import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Table, Spinner, Alert, Button } from 'react-bootstrap';
import TransactionService from '../services/TransactionService.js';
// import AccountService from '../services/AccountService.js';

const History = () => {
    const { accountId } = useParams();
    const [transactions, setTransactions] = useState([]);
    // eslint-disable-next-line no-unused-vars
    const [accountDetails, setAccountDetails] = useState(null); //
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        setLoading(true);
        setError('');

        // We can fetch account details first (optional) - CURRENTLY COMMENTED OUT
        /*
        AccountService.getAccountDetails(accountId)
            .then(response => {
                setAccountDetails(response.data); // <-- Would be used here
            })
            .catch(err => {
                 console.error("Hesap detayı alınamadı:", err);
            });
        */

        TransactionService.getTransactionHistory(accountId)
            .then(response => {
                setTransactions(response.data);
                setLoading(false);
            })
            .catch(error => {
                const errorMsg = (error.response?.data?.message) || error.message || error.toString();
                if (error.response && error.response.status === 401) { setError("Oturum süreniz dolmuş olabilir. Lütfen tekrar giriş yapın."); }
                else if (error.response && error.response.status === 404) { setError("Hesap bulunamadı veya bu hesaba erişim yetkiniz yok."); }
                else { setError("İşlem geçmişi yüklenemedi: " + errorMsg); }
                setLoading(false);
            });

    }, [accountId]);

    const formatCurrency = (amount) => {
        const numericAmount = typeof amount === 'number' ? amount : parseFloat(amount) || 0;
        return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(numericAmount);
    };

    const formatDate = (dateString) => {
        if (!dateString) return '';
        const options = { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        return new Date(dateString).toLocaleDateString('tr-TR', options);
    };

    if (loading) {
        return <div className="text-center"><Spinner animation="border" /> İşlem geçmişi yükleniyor...</div>;
    }

    if (error) {
        return <Alert variant="danger">{error}</Alert>;
    }

    return (
        <div>
            <h2>İşlem Geçmişi {accountDetails ? `- ${accountDetails.name} (${accountDetails.number})` : `(ID: ${accountId})`}</h2>
            <Button as={Link} to="/" variant="secondary" size="sm" className="mb-3">Geri Dön</Button>

            {transactions.length === 0 ? (
                <p>Bu hesaba ait işlem bulunmamaktadır.</p>
            ) : (
                <Table striped bordered hover responsive size="sm">
                    <thead>
                    <tr>
                        <th>Tarih</th>
                        <th>Açıklama</th>
                        <th>Tutar</th>
                        <th>Durum</th>
                    </tr>
                    </thead>
                    <tbody>
                    {transactions.map(tx => (
                        <tr key={tx.id}>
                            <td>{formatDate(tx.transactionDate)}</td>
                            <td>
                                {tx.from?.id === accountId ? `Gönderilen: ${tx.to?.name || tx.to?.id}` : `Gelen: ${tx.from?.name || tx.from?.id}`}
                            </td>
                            <td className={tx.from?.id === accountId ? 'text-danger' : 'text-success'}>
                                {tx.from?.id === accountId ? '-' : '+'}
                                {formatCurrency(tx.amount)}
                            </td>
                            <td>
                                    <span className={`badge ${tx.status === 'SUCCESS' ? 'bg-success' : 'bg-danger'}`}>
                                        {tx.status}
                                    </span>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </Table>
            )}
        </div>
    );
};

export default History;