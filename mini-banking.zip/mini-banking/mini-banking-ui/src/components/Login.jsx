import React, { useState } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom'; // Added 'useNavigate' for navigation
import AuthService from '../services/AuthService'; // Imported AuthService

const Login = () => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    const navigate = useNavigate(); // Get the navigation function

    const handleLogin = (e) => {
        e.preventDefault();
        setError("");
        setLoading(true);

        // 1. Call the 'login' function from AuthService
        AuthService.login(username, password)
            .then(
                () => {
                    // 2. If login is successful (token saved to Local Storage)
                    navigate("/"); // Redirect user to the homepage (Dashboard)
                    window.location.reload(); // Reload the page to update the Navbar
                },
                (error) => {
                    // 3. Giriş başarısız olursa (örn: şifre yanlış)
                    const resMessage =
                        (error.response &&
                            error.response.data &&
                            error.response.data.message) ||
                        error.message ||
                        error.toString();

                    setError(resMessage); // Hata mesajını göster
                    setLoading(false); // Buton kilidini aç
                }
            );
    };

    return (
        <div className="container mt-5">
            <div className="row justify-content-center">
                <div className="col-md-6">
                    <h2>Giriş Yap</h2>
                    <Form onSubmit={handleLogin}>
                        {error && <Alert variant="danger">{error}</Alert>}

                        <Form.Group className="mb-3" controlId="formBasicUsernameLogin">
                            <Form.Label>Kullanıcı Adı</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Kullanıcı adınızı girin"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                            />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formBasicPasswordLogin">
                            <Form.Label>Şifre</Form.Label>
                            <Form.Control
                                type="password"
                                placeholder="Şifrenizi girin"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                            />
                        </Form.Group>

                        <Button variant="primary" type="submit" disabled={loading}>
                            {loading && (
                                <span className="spinner-border spinner-border-sm"></span>
                            )}
                            <span> Giriş Yap</span>
                        </Button>

                        <div className="mt-3">
                            <p>
                                Hesabınız yok mu? <Link to="/register">Hemen Kayıt Olun</Link>
                            </p>
                        </div>
                    </Form>
                </div>
            </div>
        </div>
    );
};

export default Login;