import React, { useState } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';
// Import the AuthService we created
import AuthService from '../services/AuthService';

const Register = () => {
    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const [error, setError] = useState("");
    const [success, setSuccess] = useState(false);
    const [loading, setLoading] = useState(false); // Used to disable the button while the request is in progress


    const handleRegister = (e) => {
        e.preventDefault();
        setError("");
        setSuccess(false);
        setLoading(true); // Loading...

        // 1. Call the 'register' function from AuthService
        AuthService.register(username, email, password)
            .then(
                () => { // <--
                    // 2. If a SUCCESS (200 OK) response is returned from the backend
                    setSuccess(true); // Show the success message
                    setError("");
                    setLoading(false); // Unlock the button

                    // Formu temizle
                    setUsername("");
                    setEmail("");
                    setPassword("");
                },
                (error) => {
                    // 3. If a FAILURE (400 Bad Request, etc.) response is returned from the backend
                    // (e.g., "Username already taken")
                    const resMessage =
                        (error.response &&
                            error.response.data &&
                            error.response.data.message) ||
                        error.message ||
                        error.toString();

                    setError(resMessage); // Display the received error message in the Alert
                    setSuccess(false);
                    setLoading(false); // Unlock the button
                }
            );
    };

    return (
        <div className="container mt-5">
            <div className="row justify-content-center">
                <div className="col-md-6">
                    <h2>Kayıt Ol</h2>
                    <Form onSubmit={handleRegister}>
                        {/* Hata Mesajı Alanı */}
                        {error && <Alert variant="danger">{error}</Alert>}

                        {/* Başarı Mesajı Alanı */}
                        {success && <Alert variant="success">Kayıt başarıyla tamamlandı! Lütfen giriş yapın.</Alert>}

                        <Form.Group className="mb-3" controlId="formBasicUsername">
                            <Form.Label>Kullanıcı Adı</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Kullanıcı adınızı girin"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                            />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>Email Adresi</Form.Label>
                            <Form.Control
                                type="email"
                                placeholder="Email adresinizi girin"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formBasicPassword">
                            <Form.Label>Şifre</Form.Label>
                            <Form.Control
                                type="password"
                                placeholder="Şifrenizi girin"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                            />
                        </Form.Group>

                        <Button variant="primary" type="submit" disabled={loading}>
                            {/* Yükleniyorsa 'Spinner' (dönen) ikon, yüklenmiyorsa 'Kayıt Ol' yaz */}
                            {loading && (
                                <span className="spinner-border spinner-border-sm"></span>
                            )}
                            <span> Kayıt Ol</span>
                        </Button>
                    </Form>
                </div>
            </div>
        </div>
    );
};

export default Register;