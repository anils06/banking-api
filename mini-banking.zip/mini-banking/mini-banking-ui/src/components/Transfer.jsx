import React, { useState, useEffect } from 'react';
// ---
import { Form, Button, Alert, Spinner, Card, InputGroup } from 'react-bootstrap';
// ---
import AccountService from '../services/AccountService.js';
import TransactionService from '../services/TransactionService.js';

const Transfer = () => {
    // States
    const [accounts, setAccounts] = useState([]);
    const [fromAccountId, setFromAccountId] = useState('');
    const [toAccountId, setToAccountId] = useState('');
    const [amount, setAmount] = useState('');
    const [loadingAccounts, setLoadingAccounts] = useState(true);
    const [transferring, setTransferring] = useState(false);
    const [error, setError] = useState('');
    const [transferError, setTransferError] = useState('');
    const [transferSuccess, setTransferSuccess] = useState('');

    useEffect(() => {
        AccountService.getAccounts()
            .then(response => {
                setAccounts(response.data);
                setLoadingAccounts(false);
                if (response.data.length > 0) {
                    setFromAccountId(response.data[0].id);
                }
            })
            .catch(error => {
                const errorMsg = (error.response?.data?.message) || error.message || error.toString();
                setError("Hesaplarınız yüklenemedi: " + errorMsg);
                setLoadingAccounts(false);
            });
    }, []);

    const handleTransfer = (e) => {
        e.preventDefault();
        setTransferError('');
        setTransferSuccess('');
        setTransferring(true);

        const transferData = {
            fromAccountId: fromAccountId,
            toAccountId: toAccountId,
            amount: amount
        };

        TransactionService.transferMoney(transferData)
            .then(() => {
                setTransferSuccess(`Transfer başarıyla tamamlandı!`);
                setTransferring(false);
                setAmount('');
                // Optional: we can refresh the accounts list to update sender’s balance
                // AccountService.getAccounts().then(response => setAccounts(response.data));
            })
            .catch(error => {
                const errorMsg = (error.response?.data?.message) || error.message || error.toString();
                setTransferError("Transfer başarısız: " + errorMsg);
                setTransferring(false);
            });
    };

    if (loadingAccounts) {
        return <div className="text-center"><Spinner animation="border" /> Hesaplar yükleniyor...</div>;
    }

    if (error) {
        return <Alert variant="danger">{error}</Alert>;
    }

    if (accounts.length === 0) {
        return <Alert variant="warning">Transfer yapabilmek için önce bir hesabınız olmalı.</Alert>;
    }

    return (
        <Card>
            <Card.Header>Hesaplar Arası Transfer</Card.Header>
            <Card.Body>
                {transferError && <Alert variant="danger">{transferError}</Alert>}
                {transferSuccess && <Alert variant="success">{transferSuccess}</Alert>}
                <Form onSubmit={handleTransfer}>
                    <Form.Group className="mb-3" controlId="fromAccount">
                        <Form.Label>Gönderen Hesap</Form.Label>
                        <Form.Select
                            value={fromAccountId}
                            onChange={(e) => setFromAccountId(e.target.value)}
                            required
                        >
                            {accounts.map(account => (
                                <option key={account.id} value={account.id}>
                                    {account.name} ({account.number}) - Bakiye: {account.balance} {/* TODO: Format currency */}
                                </option>
                            ))}
                        </Form.Select>
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="toAccount">
                        <Form.Label>Alıcı Hesap ID</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Alıcı hesabın ID'sini girin"
                            value={toAccountId}
                            onChange={(e) => setToAccountId(e.target.value)}
                            required
                        />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="amount">
                        <Form.Label>Tutar</Form.Label>
                        <InputGroup> {/* This should now be recognized */}
                            <InputGroup.Text>₺</InputGroup.Text>
                            <Form.Control
                                type="number"
                                step="0.01"
                                placeholder="0.00"
                                value={amount}
                                onChange={(e) => setAmount(e.target.value)}
                                required
                                min="0.01"
                            />
                        </InputGroup>
                    </Form.Group>

                    <Button variant="primary" type="submit" disabled={transferring}>
                        {transferring && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true"/>}
                        {' '}Transfer Yap
                    </Button>
                </Form>
            </Card.Body>
        </Card>
    );
};

export default Transfer;