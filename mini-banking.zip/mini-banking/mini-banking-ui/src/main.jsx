import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom'; // Imported the Router
import App from './App.jsx';
import './index.css';

// Including Bootstrap CSS in our project
import 'bootstrap/dist/css/bootstrap.min.css';

ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode>
        {/* Wrapping the entire 'App' component with 'BrowserRouter' */}
        {/* This allows us to use links and pages within the application */}
        <BrowserRouter>
            <App />
        </BrowserRouter>
    </React.StrictMode>,
);