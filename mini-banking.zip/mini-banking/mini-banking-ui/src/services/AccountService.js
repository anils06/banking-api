import apiClient from '../api'; // Axios yerine kendi interceptor'lı client'ımızı import ediyoruz

// Kullanıcının hesaplarını getiren fonksiyon
const getAccounts = () => {
    // GET /api/accounts isteği
    // Token, api.js'deki interceptor tarafından otomatik eklenecek.
    return apiClient.get("/accounts");
};

// Yeni hesap oluşturan fonksiyon
const createAccount = (accountData) => {
    // POST /api/accounts isteği
    return apiClient.post("/accounts", accountData);
};

// Hesap detayını getiren fonksiyon
const getAccountDetails = (accountId) => {
    // GET /api/accounts/{id} isteği
    return apiClient.get(`/accounts/${accountId}`);
};

// Hesap arama fonksiyonu
const searchAccounts = (searchCriteria) => {
    // POST /api/accounts/search isteği
    return apiClient.post("/accounts/search", searchCriteria);
};

// Hesabı güncelleyen fonksiyon
const updateAccount = (accountId, accountData) => {
    // PUT /api/accounts/{id} isteği
    return apiClient.put(`/accounts/${accountId}`, accountData);
};

// Hesabı silen fonksiyon
const deleteAccount = (accountId) => {
    // DELETE /api/accounts/{id} isteği
    return apiClient.delete(`/accounts/${accountId}`);
};

const AccountService = {
    getAccounts,
    createAccount,
    getAccountDetails,
    searchAccounts,
    updateAccount,
    deleteAccount,
};

export default AccountService;