import axios from 'axios';

// Backend API'mızın ana adresi
const API_URL = "http://localhost:8080/api/users/";

// Kayıt Ol (Register) fonksiyonu
const register = (username, email, password) => {
    return axios.post(API_URL + "register", {
        username,
        email,
        password,
    });
};

// Giriş Yap (Login) fonksiyonu
const login = (username, password) => {
    return axios
        .post(API_URL + "login", {
            username,
            password,
        })
        .then((response) => {
            if (response.data.token) {
                localStorage.setItem("user", JSON.stringify(response.data));
            }
            return response.data;
        });
};

// Çıkış Yap (Logout) fonksiyonu
const logout = () => {
    localStorage.removeItem("user");
};

// Mevcut (giriş yapmış) kullanıcıyı Local Storage'dan alma fonksiyonu
const getCurrentUser = () => {
    const userStr = localStorage.getItem("user");
    if (userStr) {
        try {
            // JSON.parse hata verebilir diye try-catch ekleyelim
            return JSON.parse(userStr);
        } catch (e) {
            console.error("Error parsing user data from localStorage", e);
            // Hatalı veri varsa silelim
            localStorage.removeItem("user");
            return null;
        }
    }
    return null;
};

// Bu fonksiyonları başka dosyalarda kullanabilmek için export ediyoruz
const AuthService = {
    register,
    login,
    logout,
    getCurrentUser, //
};

export default AuthService;