import apiClient from '../api'; // Axios yerine kendi interceptor'lı client'ımızı import ediyoruz

// Para transferi işlemini başlatan fonksiyon
const transferMoney = (transferData) => {
    // transferData = { fromAccountId, toAccountId, amount }
    // POST /api/transactions/transfer isteği
    // Token, api.js'deki interceptor tarafından otomatik eklenecek.
    return apiClient.post("/transactions/transfer", transferData);
};

// Bir hesabın işlem geçmişini getiren fonksiyon
const getTransactionHistory = (accountId) => {
    // GET /api/transactions/account/{accountId} isteği
    return apiClient.get(`/transactions/account/${accountId}`);
};


const TransactionService = {
    transferMoney,
    getTransactionHistory,
};

export default TransactionService;