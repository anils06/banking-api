import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
    plugins: [
        react({
            // Enable the 'fastRefresh' setting to fix the Preamble error.
            // This ensures Vite correctly injects the hot-reloading code.
            fastRefresh: true,
        }),
    ],
    server: {
        port: 5174, // Keeps the port on which our project runs
        headers: {
            // Adds 'unsafe-inline' and 'unsafe-eval' to the CSP policy to fix errors.
            // WARNING: This is for development purposes only btw. These restrictions should be removed in production.
            'Content-Security-Policy': "script-src 'self' 'unsafe-eval' 'unsafe-inline' blob:;",
        },
    }
})